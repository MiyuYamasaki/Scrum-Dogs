var searchData=
[
  ['text_41',['Text',['../class_text.html#a3d3354273ebf2d3d92a8a485a2eb818f',1,'Text']]]
];
