var searchData=
[
  ['get_5farea_35',['get_area',['../class_circle.html#a1fb9f204616725613e45b7cce7bafe28',1,'Circle::get_area()'],['../class_square.html#a2a9abf917889bfc628ee22c791fd6b5f',1,'Square::get_area()']]],
  ['get_5fperimeter_36',['get_perimeter',['../class_circle.html#a6b74adcd6bd8d01e5cd3d8df793edc66',1,'Circle::get_perimeter()'],['../class_square.html#a32134858fac79c521b554a00df119e87',1,'Square::get_perimeter()']]]
];
