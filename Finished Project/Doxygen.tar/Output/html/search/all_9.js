var searchData=
[
  ['text_14',['Text',['../class_text.html',1,'Text'],['../class_text.html#a3d3354273ebf2d3d92a8a485a2eb818f',1,'Text::Text()']]]
];
