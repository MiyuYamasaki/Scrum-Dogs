var searchData=
[
  ['text_30',['Text',['../class_text.html',1,'']]]
];
