#ifndef TEXT_H
#define TEXT_H

#include <shapes.h>

using namespace gProject;
/* A Text Class */
class Text : public shapes
/*!  The text class is a custom container class derived from shapes class.*/
{
    public:
        Text(RenderArea *ra);	/*!< alternate constructor */
    //! This constructor renders the area
    private:
};

#endif // TEXT_H
