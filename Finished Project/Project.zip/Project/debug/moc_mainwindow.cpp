/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[35];
    char stringdata0[943];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 33), // "on_Brush_Color_ComboBox_activ..."
QT_MOC_LITERAL(2, 45, 0), // ""
QT_MOC_LITERAL(3, 46, 5), // "index"
QT_MOC_LITERAL(4, 52, 36), // "on_Pen_Join_Style_ComboBox_ac..."
QT_MOC_LITERAL(5, 89, 33), // "on_Brush_Style_ComboBox_activ..."
QT_MOC_LITERAL(6, 123, 32), // "on_Text_Color_ComboBox_activated"
QT_MOC_LITERAL(7, 156, 35), // "on_Pen_Cap_Style_ComboBox_act..."
QT_MOC_LITERAL(8, 192, 31), // "on_Pen_Style_ComboBox_activated"
QT_MOC_LITERAL(9, 224, 32), // "on_Pen_Width_LineEdit_textEdited"
QT_MOC_LITERAL(10, 257, 4), // "arg1"
QT_MOC_LITERAL(11, 262, 31), // "on_Pen_Color_ComboBox_activated"
QT_MOC_LITERAL(12, 294, 33), // "on_Shape_Type_Combo_Box_activ..."
QT_MOC_LITERAL(13, 328, 32), // "on_Shape_Dim_LineEdit_textEdited"
QT_MOC_LITERAL(14, 361, 32), // "on_Allignment_ComboBox_activated"
QT_MOC_LITERAL(15, 394, 38), // "on_Text_Point_Size_LineEdit_t..."
QT_MOC_LITERAL(16, 433, 27), // "on_Text_LineEdit_textEdited"
QT_MOC_LITERAL(17, 461, 34), // "on_Font_Family_LineEdit_textE..."
QT_MOC_LITERAL(18, 496, 32), // "on_Font_Style_ComboBox_activated"
QT_MOC_LITERAL(19, 529, 33), // "on_Font_Weight_ComboBox_activ..."
QT_MOC_LITERAL(20, 563, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(21, 585, 26), // "on_tabWidget_tabBarClicked"
QT_MOC_LITERAL(22, 612, 10), // "closeEvent"
QT_MOC_LITERAL(23, 623, 12), // "QCloseEvent*"
QT_MOC_LITERAL(24, 636, 5), // "event"
QT_MOC_LITERAL(25, 642, 34), // "on_Delete_Shape_ComboBox_acti..."
QT_MOC_LITERAL(26, 677, 34), // "on_pushButton_delete_shape_cl..."
QT_MOC_LITERAL(27, 712, 29), // "on_pushButton_refresh_clicked"
QT_MOC_LITERAL(28, 742, 44), // "on_Delete_Shape_ComboBox_curr..."
QT_MOC_LITERAL(29, 787, 26), // "on_pushButton_edit_clicked"
QT_MOC_LITERAL(30, 814, 29), // "on_pushButton_contact_clicked"
QT_MOC_LITERAL(31, 844, 28), // "on_pushButton_testim_clicked"
QT_MOC_LITERAL(32, 873, 21), // "on_Reports_Id_clicked"
QT_MOC_LITERAL(33, 895, 23), // "on_Reports_Area_clicked"
QT_MOC_LITERAL(34, 919, 23) // "on_Reports_Peri_clicked"

    },
    "MainWindow\0on_Brush_Color_ComboBox_activated\0"
    "\0index\0on_Pen_Join_Style_ComboBox_activated\0"
    "on_Brush_Style_ComboBox_activated\0"
    "on_Text_Color_ComboBox_activated\0"
    "on_Pen_Cap_Style_ComboBox_activated\0"
    "on_Pen_Style_ComboBox_activated\0"
    "on_Pen_Width_LineEdit_textEdited\0arg1\0"
    "on_Pen_Color_ComboBox_activated\0"
    "on_Shape_Type_Combo_Box_activated\0"
    "on_Shape_Dim_LineEdit_textEdited\0"
    "on_Allignment_ComboBox_activated\0"
    "on_Text_Point_Size_LineEdit_textEdited\0"
    "on_Text_LineEdit_textEdited\0"
    "on_Font_Family_LineEdit_textEdited\0"
    "on_Font_Style_ComboBox_activated\0"
    "on_Font_Weight_ComboBox_activated\0"
    "on_pushButton_clicked\0on_tabWidget_tabBarClicked\0"
    "closeEvent\0QCloseEvent*\0event\0"
    "on_Delete_Shape_ComboBox_activated\0"
    "on_pushButton_delete_shape_clicked\0"
    "on_pushButton_refresh_clicked\0"
    "on_Delete_Shape_ComboBox_currentIndexChanged\0"
    "on_pushButton_edit_clicked\0"
    "on_pushButton_contact_clicked\0"
    "on_pushButton_testim_clicked\0"
    "on_Reports_Id_clicked\0on_Reports_Area_clicked\0"
    "on_Reports_Peri_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      29,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  159,    2, 0x08 /* Private */,
       4,    1,  162,    2, 0x08 /* Private */,
       5,    1,  165,    2, 0x08 /* Private */,
       6,    1,  168,    2, 0x08 /* Private */,
       7,    1,  171,    2, 0x08 /* Private */,
       8,    1,  174,    2, 0x08 /* Private */,
       9,    1,  177,    2, 0x08 /* Private */,
      11,    1,  180,    2, 0x08 /* Private */,
      12,    1,  183,    2, 0x08 /* Private */,
      13,    1,  186,    2, 0x08 /* Private */,
      14,    1,  189,    2, 0x08 /* Private */,
      15,    1,  192,    2, 0x08 /* Private */,
      16,    1,  195,    2, 0x08 /* Private */,
      17,    1,  198,    2, 0x08 /* Private */,
      18,    1,  201,    2, 0x08 /* Private */,
      19,    1,  204,    2, 0x08 /* Private */,
      20,    0,  207,    2, 0x08 /* Private */,
      21,    1,  208,    2, 0x08 /* Private */,
      22,    1,  211,    2, 0x08 /* Private */,
      25,    1,  214,    2, 0x08 /* Private */,
      26,    0,  217,    2, 0x08 /* Private */,
      27,    0,  218,    2, 0x08 /* Private */,
      28,    1,  219,    2, 0x08 /* Private */,
      29,    0,  222,    2, 0x08 /* Private */,
      30,    0,  223,    2, 0x08 /* Private */,
      31,    0,  224,    2, 0x08 /* Private */,
      32,    0,  225,    2, 0x08 /* Private */,
      33,    0,  226,    2, 0x08 /* Private */,
      34,    0,  227,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, 0x80000000 | 23,   24,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_Brush_Color_ComboBox_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->on_Pen_Join_Style_ComboBox_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->on_Brush_Style_ComboBox_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->on_Text_Color_ComboBox_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->on_Pen_Cap_Style_ComboBox_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->on_Pen_Style_ComboBox_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->on_Pen_Width_LineEdit_textEdited((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 7: _t->on_Pen_Color_ComboBox_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->on_Shape_Type_Combo_Box_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->on_Shape_Dim_LineEdit_textEdited((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: _t->on_Allignment_ComboBox_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->on_Text_Point_Size_LineEdit_textEdited((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 12: _t->on_Text_LineEdit_textEdited((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 13: _t->on_Font_Family_LineEdit_textEdited((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 14: _t->on_Font_Style_ComboBox_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->on_Font_Weight_ComboBox_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->on_pushButton_clicked(); break;
        case 17: _t->on_tabWidget_tabBarClicked((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->closeEvent((*reinterpret_cast< QCloseEvent*(*)>(_a[1]))); break;
        case 19: _t->on_Delete_Shape_ComboBox_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->on_pushButton_delete_shape_clicked(); break;
        case 21: _t->on_pushButton_refresh_clicked(); break;
        case 22: _t->on_Delete_Shape_ComboBox_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 23: _t->on_pushButton_edit_clicked(); break;
        case 24: _t->on_pushButton_contact_clicked(); break;
        case 25: _t->on_pushButton_testim_clicked(); break;
        case 26: _t->on_Reports_Id_clicked(); break;
        case 27: _t->on_Reports_Area_clicked(); break;
        case 28: _t->on_Reports_Peri_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 29)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 29;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 29)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 29;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
