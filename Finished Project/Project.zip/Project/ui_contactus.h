/********************************************************************************
** Form generated from reading UI file 'contactus.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONTACTUS_H
#define UI_CONTACTUS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_contactUs
{
public:
    QLabel *Picture;
    QPlainTextEdit *teamName;
    QPlainTextEdit *Names;

    void setupUi(QWidget *contactUs)
    {
        if (contactUs->objectName().isEmpty())
            contactUs->setObjectName(QString::fromUtf8("contactUs"));
        contactUs->resize(400, 300);
        Picture = new QLabel(contactUs);
        Picture->setObjectName(QString::fromUtf8("Picture"));
        Picture->setGeometry(QRect(0, 20, 401, 281));
        Picture->setPixmap(QPixmap(QString::fromUtf8("../../../Pics/image0.jpg")));
        teamName = new QPlainTextEdit(contactUs);
        teamName->setObjectName(QString::fromUtf8("teamName"));
        teamName->setGeometry(QRect(0, 0, 161, 21));
        Names = new QPlainTextEdit(contactUs);
        Names->setObjectName(QString::fromUtf8("Names"));
        Names->setGeometry(QRect(310, 0, 91, 91));

        retranslateUi(contactUs);

        QMetaObject::connectSlotsByName(contactUs);
    } // setupUi

    void retranslateUi(QWidget *contactUs)
    {
        contactUs->setWindowTitle(QApplication::translate("contactUs", "Form", nullptr));
        Picture->setText(QString());
        teamName->setPlainText(QApplication::translate("contactUs", "Contact Us: ScrumDogs", nullptr));
        Names->setPlainText(QApplication::translate("contactUs", "Grant Yamaguchi\n"
"Nathan Kim\n"
"Suqi Hu\n"
"Ian Oh\n"
"Patrick Moir\n"
"Jorge", nullptr));
    } // retranslateUi

};

namespace Ui {
    class contactUs: public Ui_contactUs {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONTACTUS_H
