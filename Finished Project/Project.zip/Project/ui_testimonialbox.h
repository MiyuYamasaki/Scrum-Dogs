/********************************************************************************
** Form generated from reading UI file 'testimonialbox.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TESTIMONIALBOX_H
#define UI_TESTIMONIALBOX_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_testimonialbox
{
public:
    QLabel *label;
    QPushButton *pushButton;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;

    void setupUi(QDialog *testimonialbox)
    {
        if (testimonialbox->objectName().isEmpty())
            testimonialbox->setObjectName(QString::fromUtf8("testimonialbox"));
        testimonialbox->resize(400, 300);
        label = new QLabel(testimonialbox);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 0, 55, 16));
        pushButton = new QPushButton(testimonialbox);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(290, 260, 93, 28));
        lineEdit = new QLineEdit(testimonialbox);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(10, 20, 113, 22));
        lineEdit_2 = new QLineEdit(testimonialbox);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(10, 50, 371, 201));

        retranslateUi(testimonialbox);

        QMetaObject::connectSlotsByName(testimonialbox);
    } // setupUi

    void retranslateUi(QDialog *testimonialbox)
    {
        testimonialbox->setWindowTitle(QApplication::translate("testimonialbox", "Dialog", nullptr));
        label->setText(QApplication::translate("testimonialbox", "Name:", nullptr));
        pushButton->setText(QApplication::translate("testimonialbox", "OK", nullptr));
    } // retranslateUi

};

namespace Ui {
    class testimonialbox: public Ui_testimonialbox {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TESTIMONIALBOX_H
