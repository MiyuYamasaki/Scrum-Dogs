#include <iostream>
#include "vector.h"

int main() 
{
  int num = 3;
  int *ptr = &num;
  vector<int> v1(5);
  for (int i = 0; i < 5; i++)
  {
    v1.push_back(ptr);
  }

  vector<int> v2(v1); // test the copy constructor

  vector <int> v3; //test the copy assignment.
  
  v3 = v1;
  v1.reserve(10);
  cout << "Testing the vector class:\n output vector v1:  ";
  for (int i = 0; i < v1.size(); i++)
  {
    cout << v1[i] << " ";
  }
  return 0;
}
